import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.pipeline import Pipeline

# Cargar los datos desde el archivo Excel
df = pd.read_excel(r'C:\Users\majit\Desktop\Modelo Mantenimiento\mantenimiento_predictivo_patineta.xlsx')

# Eliminar espacios adicionales en los nombres de las columnas
df.columns = df.columns.str.strip()

# Separar características y etiquetas
X = df[['Tiempo_uso', 'Bateria', 'Temperatura_motor', 'Velocidad', 'Distancia_recorrida']]
y = df['Falla (1 = Si, 0 = No)']

# Balancear las clases con SMOTE si es necesario
smote = SMOTE(random_state=42)
X_res, y_res = smote.fit_resample(X, y)

# Dividir los datos en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X_res, y_res, test_size=0.2, random_state=42)

# Normalizar las características
scaler = StandardScaler()

# Definir los modelos y su ajuste de hiperparámetros con GridSearchCV
models = {
    'Gradient Boosting': GradientBoostingClassifier(),
    'Random Forest': RandomForestClassifier(),
    'SVM': SVC()
}

# Hiperparámetros a ajustar para cada modelo (agregando el prefijo 'model__')
params = {
    'Gradient Boosting': {
        'model__n_estimators': [100, 200],
        'model__learning_rate': [0.01, 0.1, 0.05],
        'model__max_depth': [3, 5, 7]
    },
    'Random Forest': {
        'model__n_estimators': [100, 200],
        'model__max_depth': [10, 20],
        'model__min_samples_split': [2, 5]
    },
    'SVM': {
        'model__C': [0.1, 1, 10],
        'model__kernel': ['linear', 'rbf']
    }
}

# Ejecutar validación cruzada y ajuste de hiperparámetros con GridSearchCV
for name, model in models.items():
    print(f"\nEntrenando modelo: {name}")
    pipeline = Pipeline([
        ('scaler', scaler),
        ('model', model)
    ])
    grid = GridSearchCV(pipeline, params[name], cv=5, scoring='accuracy', n_jobs=-1)
    grid.fit(X_train, y_train)
    
    # Obtener el mejor modelo y sus parámetros
    print(f"Mejores parámetros para {name}: {grid.best_params_}")
    
    # Evaluar en los datos de prueba
    y_pred = grid.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f'Precisión del modelo {name}: {accuracy}')

# Evaluar los modelos con validación cruzada en el conjunto de entrenamiento
for name, model in models.items():
    print(f"\nEvaluando {name} con validación cruzada")
    pipeline = Pipeline([
        ('scaler', scaler),
        ('model', model)
    ])
    scores = cross_val_score(pipeline, X_res, y_res, cv=5, scoring='accuracy')
    print(f"Precisión media de validación cruzada para {name}: {scores.mean()}")
