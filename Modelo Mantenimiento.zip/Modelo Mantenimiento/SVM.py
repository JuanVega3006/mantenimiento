import pandas as pd
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.pipeline import Pipeline
import joblib  

# Cargar los datos desde el archivo Excel
df = pd.read_excel(r'C:\Users\majit\Desktop\Modelo Mantenimiento\mantenimiento_predictivo_patineta.xlsx')

# Eliminar espacios adicionales en los nombres de las columnas
df.columns = df.columns.str.strip()

# Separar características y etiquetas
X = df[['Tiempo_uso', 'Bateria', 'Temperatura_motor', 'Velocidad', 'Distancia_recorrida']]
y = df['Falla (1 = Si, 0 = No)']

# Balancear las clases con SMOTE si es necesario
smote = SMOTE(random_state=42)
X_res, y_res = smote.fit_resample(X, y)

# Dividir los datos en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X_res, y_res, test_size=0.2, random_state=42)

# Normalizar las características
scaler = StandardScaler()

# Definir el modelo SVM
svm_model = SVC()

# Definir los hiperparámetros para ajustar
svm_params = {
    'model__C': [0.1, 1, 10],
    'model__kernel': ['linear', 'rbf']
}

# Crear el pipeline para SVM
pipeline = Pipeline([
    ('scaler', scaler),      # Normalización
    ('model', svm_model)     # Modelo SVM
])

# Ajuste de hiperparámetros con GridSearchCV
grid = GridSearchCV(pipeline, svm_params, cv=5, scoring='accuracy', n_jobs=-1)
grid.fit(X_train, y_train)

# Obtener el mejor modelo SVM
best_svm = grid.best_estimator_

# Evaluar en los datos de prueba
y_pred = best_svm.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f'Precisión del modelo SVM: {accuracy}')

# Guardar el modelo SVM entrenado
joblib.dump(best_svm, 'modelo_svm_entrenado.pkl')
print("Modelo SVM guardado como 'modelo_svm_entrenado.pkl'")

# Validación cruzada del mejor modelo SVM en el conjunto de entrenamiento
scores = cross_val_score(best_svm, X_res, y_res, cv=5, scoring='accuracy')
print(f"Precisión media de validación cruzada para SVM: {scores.mean()}")
