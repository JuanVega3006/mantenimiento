import tkinter as tk
from tkinter import messagebox
import joblib
import numpy as np
from sklearn.preprocessing import StandardScaler

# Cargar el modelo entrenado
modelo_svm = joblib.load('modelo_svm_entrenado.pkl')

# Crear la ventana principal
window = tk.Tk()
window.title("Predicción de Fallo de Patineta Eléctrica")

# Etiquetas y campos de entrada para cada característica
labels = ["Tiempo de uso (h)", "Batería (%)", "Temperatura del motor (°C)", "Velocidad (km/h)", "Distancia recorrida (km)"]
entries = []

for label in labels:
    tk.Label(window, text=label).pack()
    entry = tk.Entry(window)
    entry.pack()
    entries.append(entry)

# Función para predecir el fallo
def predecir_fallo():
    try:
        # Obtener los valores ingresados por el usuario
        tiempo_uso = float(entries[0].get())
        bateria = float(entries[1].get())
        temperatura_motor = float(entries[2].get())
        velocidad = float(entries[3].get())
        distancia_recorrida = float(entries[4].get())

        # Crear un array con los valores
        datos_usuario = np.array([[tiempo_uso, bateria, temperatura_motor, velocidad, distancia_recorrida]])

        # Escalar los datos de entrada antes de predecir (asegurarse de usar el mismo scaler que se usó al entrenar)
        scaler = StandardScaler()
        datos_usuario_scaled = scaler.fit_transform(datos_usuario)

        # Realizar la predicción
        prediccion = modelo_svm.predict(datos_usuario_scaled)

        # Mostrar el resultado al usuario
        if prediccion[0] == 1:
            messagebox.showinfo("Resultado", "La patineta probablemente fallará.")
        else:
            messagebox.showinfo("Resultado", "La patineta probablemente NO fallará.")
    except ValueError:
        messagebox.showerror("Error", "Por favor, ingresa valores numéricos válidos.")

# Botón para realizar la predicción
tk.Button(window, text="Predecir fallo", command=predecir_fallo).pack()

# Iniciar la interfaz gráfica
window.mainloop()
